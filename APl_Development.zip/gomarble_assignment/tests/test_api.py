import os
from app.main import app
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock

client = TestClient(app)

def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "Welcome to the Review Extractor API!" in response.json()["message"]

def test_another_endpoint():
    # Mock the `extract_reviews` method of the `ReviewExtractor` class
    with patch.dict(os.environ, {"OPENAI_API_KEY": "mocked_api_key"}), \
         patch("app.review_extractor.ReviewExtractor.extract_reviews", new_callable=AsyncMock) as mock_extract_reviews:
        
        # Mock response for the `extract_reviews` method
        mock_extract_reviews.return_value = ["Review 1", "Review 2", "Review 3"]

        # Provide a valid URL as a query parameter
        response = client.get("/another-endpoint?url=https://mockedurl.com/product")

        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["reviews_count"] == 3
        assert data["reviews"] == ["Review 1", "Review 2", "Review 3"]

def test_another_endpoint_invalid_url():
    with patch.dict(os.environ, {"OPENAI_API_KEY": "mocked_api_key"}):
        # Call the endpoint with an invalid URL
        response = client.get("/another-endpoint?url=invalid_url")

        # Assertions for error response
        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid URL provided"
