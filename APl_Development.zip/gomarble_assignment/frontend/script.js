document.getElementById("fetch-button").addEventListener("click", async () => {
    const url = document.getElementById("url-input").value;
    const response = await fetch(`http://127.0.0.1:8000/api/reviews?page=${encodeURIComponent(url)}`);
    const data = await response.json();
    const container = document.getElementById("reviews-container");
    container.innerHTML = `<h2>Total Reviews: ${data.reviews_count}</h2>`;
    data.reviews.forEach(review => {
        const reviewDiv = document.createElement("div");
        reviewDiv.innerHTML = `<strong>${review.title}</strong>: ${review.body} (${review.rating} stars by ${review.reviewer})`;
        container.appendChild(reviewDiv);
    });
});
