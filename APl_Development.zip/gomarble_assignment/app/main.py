import os
from fastapi import FastAPI, Query, HTTPException
from app.llm_helper import LLMHelper
from app.review_extractor import ReviewExtractor
from urllib.parse import urlparse

app = FastAPI()

# Ensure the OPENAI_API_KEY environment variable is set
openai_api_key = os.getenv("OPENAI_API_KEY")
if not openai_api_key:
    raise ValueError("The 'OPENAI_API_KEY' environment variable is not set.")

@app.get("/")
def read_root():
    return {"message": "Welcome to the Review Extractor API!"}

@app.get("/another-endpoint")
async def another_endpoint(url: str = Query(..., description="The product page URL to extract reviews from. Example: 'https://www.amazon.com/dp/B08X8VJQZD'")):
    """
    Endpoint to extract reviews from a product page.
    """
    # Validate the URL
    parsed_url = urlparse(url)
    if not all([parsed_url.scheme, parsed_url.netloc]):
        raise HTTPException(status_code=400, detail="Invalid URL provided")

    # Initialize helpers
    llm_helper = LLMHelper(api_key=openai_api_key)
    extractor = ReviewExtractor(llm_helper)

    try:
        # Extract reviews
        reviews = await extractor.extract_reviews(url)
        return {
            "reviews_count": len(reviews),
            "reviews": reviews,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract reviews: {str(e)}")
