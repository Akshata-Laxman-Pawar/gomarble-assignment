import openai

class LLMHelper:
    def __init__(self, api_key):
        openai.api_key = api_key

    def get_css_selector(self, html_content):
        """
        Use OpenAI's API to predict CSS selectors for reviews.
        """
        prompt = f"""
        Given the following HTML content, identify the CSS selectors for:
        - Review title
        - Review body
        - Review rating
        - Reviewer name
        
        HTML content:
        {html_content}
        
        Respond in JSON format with keys: 'title', 'body', 'rating', 'reviewer'.
        """
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150
        )
        return response.choices[0].text.strip()
