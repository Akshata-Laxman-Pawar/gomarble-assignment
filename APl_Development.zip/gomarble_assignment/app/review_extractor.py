from playwright.async_api import async_playwright
import json
import asyncio

class ReviewExtractor:
    def __init__(self, llm_helper):
        self.llm_helper = llm_helper

    async def extract_reviews(self, url):
        reviews = []
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(url)
            
            # Get page HTML and use LLM to identify CSS selectors
            html_content = await page.content()
            css_selectors = json.loads(await self.llm_helper.get_css_selector(html_content))
            
            # Extract reviews based on identified selectors
            reviews_elements = await page.query_selector_all(css_selectors['review'])
            for review in reviews_elements:
                reviews.append({
                    "title": await review.query_selector(css_selectors['title']).inner_text(),
                    "body": await review.query_selector(css_selectors['body']).inner_text(),
                    "rating": int(await review.query_selector(css_selectors['rating']).inner_text()),
                    "reviewer": await review.query_selector(css_selectors['reviewer']).inner_text()
                })
            
            # Handle pagination if available
            while await page.locator("text=Next").is_visible():
                await page.locator("text=Next").click()
                await page.wait_for_load_state("networkidle")
                more_reviews = await page.query_selector_all(css_selectors['review'])
                for review in more_reviews:
                    reviews.append({
                        "title": await review.query_selector(css_selectors['title']).inner_text(),
                        "body": await review.query_selector(css_selectors['body']).inner_text(),
                        "rating": int(await review.query_selector(css_selectors['rating']).inner_text()),
                        "reviewer": await review.query_selector(css_selectors['reviewer']).inner_text()
                    })

            await browser.close()
        return reviews
